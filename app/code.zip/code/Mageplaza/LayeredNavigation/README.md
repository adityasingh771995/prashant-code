## Documentation

- Installation guide: https://www.mageplaza.com/install-magento-2-extension/#solution-1-ready-to-paste
- User guide: https://docs.mageplaza.com/layered-navigation-m2/
- Report a security issue to security@mageplaza.com