var config = {
    paths: {
        'jquery_chosen': 'Smartwave_Dailydeals/js/chosen.jquery.min'
    },
    shim: {
        'jquery_chosen': {
            deps: ['jquery']
        }
    }
};
